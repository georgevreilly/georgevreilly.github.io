Add the following line to the <ContentFilters> section of your blog's
site.config::

    <ContentFilter find="\$stars\((?&lt;expr&gt;[\d.]+)\)" replace="&lt;div&gt;&lt;img src=&quot;images/5star${expr}.gif&quot; /&gt; ${expr} stars out of 5&lt;/div&gt;" isregex="true" />

Copy 5star*.gif to your blog's images directory. The *.xcf files are Gimp 
source files.

To use, just place lines like these in your blog entries::
    $stars(3.5)
    $stars(5)

You can use 0, 0.5, 1, 1.5, ..., 4.5, and 5.
